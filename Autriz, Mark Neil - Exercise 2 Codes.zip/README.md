# Exercise-2
Autriz, Mark Neil - Exercise 2
Bachelor of Science in Computer Science

Live website link : https://mnautriz.github.io/Exercise-2/

Steps on how to create Github Page:
1. First create your own repository.
2. Create a temporary HTML file to visualize the initial content of your website.
3. Go to Settings in your repository.
4. Go to the section for "Code and automation" and Select "Pages".
5. Go to the branch and select and "Main" branch and save the changes.
6. Wait for few minutes and your Github Page and website will be deployed.

What are your key takeaways from this exercise?
In completing Programming Exercise #2 focused on crafting GitHub pages and a personal website, my key takeaway is the fusion of enjoyment and skill refinement. Delving into layouting, designing, and constructing applications for my portfolio, I found immense satisfaction in the creative process. Moreover, this exercise serves as a valuable opportunity for revisiting and honing my expertise in HTML and CSS. The endeavor not only amplifies my proficiency in web development but also grants a platform to showcase my evolving talents. It's a harmonious blend of passion and learning, propelling me towards a deeper understanding of web design and development.